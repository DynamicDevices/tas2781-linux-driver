mainApp.controller("homePageController", function($scope, $location, configDataService, $timeout, $rootScope) {

    $scope.configData;
    $scope.selectedPlatform = null;
    $scope.selectedNumOfDevices = null;
    $scope.selectedDeviceType = null;
    $scope.deviceMappings = [];

    $scope.data = {
        'selectedPlatform': null,
        'selectedNumOfDevices': null,
        'deviceMappings': []
    }

    function initialize() {
        $scope.configData = configDataService.getHardwareSetupDetails();
        var settings = configDataService.getSettings();
        if(Object.keys(settings).length > 0) {
            $scope.data.selectedPlatform = settings['platform'] || '';
            $scope.data.selectedNumOfDevices = settings['noOfDevices'] || '';
            $scope.data.deviceMappings = settings['deviceMappings'] || [];
            $scope.data.selectedDeviceType = settings['deviceType'] || '';
        }
    }

    $scope.changeMapping = function() {
        var selectedNum = parseInt($scope.data.selectedNumOfDevices);
        if(selectedNum < $scope.data.deviceMappings.length) {
            $scope.data.deviceMappings = $scope.data.deviceMappings.slice(0, selectedNum);
        } else {
            for(var i = $scope.data.deviceMappings.length; i<selectedNum; i++) {
                $scope.data.deviceMappings.push('');
            }
        }
    }

    $scope.update = function(){
        configDataService.storeHWSetupSettings($scope.data);
    };

    $scope.deviceTypeChanged = function() {
        $scope.data.selectedNumOfDevices = null;
        $scope.data.deviceMappings = [];
        $scope.changeMapping();
        $scope.configData = configDataService.getHardwareSetupDetails();
    }
    
    $scope.canGoToNextPage = function() {
        if($scope.data.selectedDeviceType === null || $scope.data.selectedDeviceType === '')
            return false;
        if(($scope.data.selectedPlatform === null || $scope.data.selectedPlatform === '') && $scope.data.selectedDeviceType === "Non Integrated")
            return false;
        if($scope.data.selectedNumOfDevices === null || $scope.data.selectedNumOfDevices === '')
            return false;
        if($scope.data.deviceMappings.indexOf('') >= 0)
            return false;
        return true;
    }

    $scope.goToNextPage = function() {
        configDataService.storeHWSetupSettings($scope.data);
        $location.path('/configurationpage')
    }


    $timeout(function() {
      initialize();
    }, 0);

    $rootScope.$on('appReload', function(){
        initialize();
    });
    $rootScope.$on('newSession', function(){
        initialize();
    });
});