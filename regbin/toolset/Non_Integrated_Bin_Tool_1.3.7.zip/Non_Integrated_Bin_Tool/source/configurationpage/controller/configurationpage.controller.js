mainApp.controller("configurationPageController", function($scope, $location, configDataService, $timeout, $q, $rootScope, StatusMessageService, binaryDump, endSystemOptions, $injector, Checksum_V2) {

    var path = require('path');
    var fs = require('fs');

    $scope.blockTypes = configDataService.getBlockTypes();
    $scope.availableAmps = configDataService.getAmpNamesWithIndex();
    $scope.selectedDeviceType = configDataService.getSettings()['deviceType'];
    var binary = configDataService.getBinaryObject();
    $scope.configurationList = [];
    $scope.selectedConfigIndex = null;
    $scope.selectedBlockIndex = null;
    $scope.selectedCommandIndex = null;
    $scope.warningPopUp = false;
    $scope.binOutputConfig = {
        binFileName: '',
        binFileFolderPath: '',
        binFileFolderName: ''
    };
    $scope.blinkSelectedConfig = false;
    $scope.blinkSelectedBlock = false;
    $scope.blinkSelectedCommand = false;
    $scope.configNameUnderEdit = [];
    $scope.configNameLength = binary.binConfig.configNameLength;
    $scope.cfgFilePath = '';
    $scope.cfgFileName = '';
    $scope.integratedBinFileName = '';

    var verifyDeviceNames = function(){
        $scope.configurationList.forEach(function(config, cindex){
            config.blocksList.forEach(function(block, bindex){
                if($scope.availableAmps.indexOf(block.deviceName)<0){
                    $scope.configurationList[cindex].blocksList[bindex].deviceName = '';
                }
            });
        });
    };
    var init = function(){
        binary = configDataService.getBinaryObject();
        $scope.configurationList = binary.configurationList;
        $scope.availableAmps = configDataService.getAmpNamesWithIndex();
        verifyDeviceNames();
        if($scope.configurationList.length){
            $scope.selectedConfigIndex = 0;
            $scope.changeSelectedConfig(0);
        }
    };

    $scope.addConfiguration = function() {
        if(binary.configurationList.length >= binary.binConfig.maxConfigs) {
            StatusMessageService.error("Maximum Number of configurations reached ( " + binary.binConfig.maxConfigs + "  Configurations)");
            return;
        }
        binary.addConfiguration();
        $scope.changeSelectedConfig($scope.configurationList.length - 1);
    };

    $scope.copyConfiguration = function(index) {
        if(binary.configurationList.length >= binary.binConfig.maxConfigs) {
            StatusMessageService.error("Maximum Number of configurations reached ( " + binary.binConfig.maxConfigs + "  Configurations)");
            return;
        }
        binary.copyConfiguration($scope.configurationList[index]);
        $scope.changeSelectedConfig($scope.configurationList.length - 1);
    };

    $scope.changeSelectedConfig = function(index) {
        $scope.selectedConfigIndex = index;
        var blocks = $scope.configurationList[$scope.selectedConfigIndex].blocksList;
        if(blocks.length == 0) {
            $scope.selectedBlockIndex = null;
            $scope.selectedCommandIndex = null;
        } else {
            $scope.changeSelectedBlock(0);
            var commands = blocks[0].commands;
            if(commands.length == 0) {
                $scope.selectedCommandIndex = null;
            } else {
                $scope.selectedCommandIndex = 0;
            }
        }
    }

    $scope.deleteConfiguration = function(index, event) {
        binary.deleteConfiguration(index);
        if(index <= $scope.selectedConfigIndex) {
            if($scope.configurationList[$scope.selectedConfigIndex-1]) {
                $scope.changeSelectedConfig($scope.selectedConfigIndex-1);
            } else if($scope.configurationList[$scope.selectedConfigIndex]) {
                $scope.changeSelectedConfig($scope.selectedConfigIndex);
            } else if($scope.configurationList[$scope.selectedConfigIndex+1]) {
                $scope.changeSelectedConfig($scope.selectedConfigIndex+1);
            } 
            else {
                $scope.selectedConfigIndex = null;
                $scope.selectedBlockIndex = null;
                $scope.selectedCommandIndex = null;
            }
        }
        event.stopPropagation();
    }

    $scope.editConfigName = function(indx, value) {
        $scope.configNameUnderEdit[indx] = value;
    }

    $scope.addBlock = function() {
        var config = $scope.configurationList[$scope.selectedConfigIndex];
        config.addBlock();
        $scope.changeSelectedBlock(config.blocksList.length - 1);
    }

    $scope.copyBlock = function(blockIndex) {
        var config = $scope.configurationList[$scope.selectedConfigIndex];
        config.copyBlock(blockIndex);
        $scope.changeSelectedBlock(config.blocksList.length - 1);
    }

    var disableMaskOrNot = function() {
        if($scope.configurationList[$scope.selectedConfigIndex].blocksList[$scope.selectedBlockIndex].deviceName == 'Common') { 
            // If device name is Common then disabling the Mask field and setting it to 0xff.
            $scope.isMaskDisable = true;
            if($scope.selectedCommandIndex!=null) {
                $scope.configurationList[$scope.selectedConfigIndex].blocksList[$scope.selectedBlockIndex].commands[$scope.selectedCommandIndex].mask = 'ff';
            }
        }        
        else {
            $scope.isMaskDisable = false;
        }      
    }

    $scope.changeSelectedBlock = function(index) {
        $scope.selectedBlockIndex = index;
        var blocks = $scope.configurationList[$scope.selectedConfigIndex].blocksList;
        if(blocks[$scope.selectedBlockIndex].commands.length == 0) {            
            $scope.selectedCommandIndex = null;
        } else {
            $scope.changeSelectedCommand(0);            
        }
        disableMaskOrNot();
    }

    $scope.deleteBlock = function(index, event) {
        var config = $scope.configurationList[$scope.selectedConfigIndex];
        config.deleteBlock(index);
        if(index <= $scope.selectedBlockIndex) {
            if($scope.configurationList[$scope.selectedConfigIndex].blocksList[$scope.selectedBlockIndex-1]) {
                $scope.changeSelectedBlock($scope.selectedBlockIndex-1);
            } else if($scope.configurationList[$scope.selectedConfigIndex].blocksList[$scope.selectedBlockIndex]) {
                $scope.changeSelectedBlock($scope.selectedBlockIndex);
            } else if($scope.configurationList[$scope.selectedConfigIndex].blocksList[$scope.selectedBlockIndex+1]) {
                $scope.changeSelectedBlock($scope.selectedBlockIndex+1);
            }
            else {
                $scope.selectedBlockIndex = null;
                $scope.selectedCommandIndex = null;
            }
        }
        event.stopPropagation();
    }

    $scope.addCommand = function() {
        var block = $scope.configurationList[$scope.selectedConfigIndex].blocksList[$scope.selectedBlockIndex];
        block.addCommand(0);
        $scope.changeSelectedCommand(0);
    }

    $scope.addCommandBelowCurrentCommand = function() {
        var block = $scope.configurationList[$scope.selectedConfigIndex].blocksList[$scope.selectedBlockIndex];
        block.addCommand($scope.selectedCommandIndex + 1);
        $scope.changeSelectedCommand($scope.selectedCommandIndex + 1);
    }

    $scope.addCommandAboveCurrentCommand = function() {
        var block = $scope.configurationList[$scope.selectedConfigIndex].blocksList[$scope.selectedBlockIndex];
        block.addCommand($scope.selectedCommandIndex);
        $scope.changeSelectedCommand($scope.selectedCommandIndex);
    }

    $scope.changeSelectedCommand = function(indx) {
        $scope.selectedCommandIndex = indx;
    }

    $scope.getCommandName = function(cmd) {
        var commandName;
        if(cmd.delay){
            commandName = "Delay"
        } else {
            commandName = "B0x"+getCommandValue(cmd.book)+" P0x"+getCommandValue(cmd.page)+" R0x"+getCommandValue(cmd.register);
        }
        return commandName;
    }

    function getCommandValue(value) {
        return ('0' + value).slice(-2);
    }

    $scope.deleteCommand = function(index, event) {
        var block = $scope.configurationList[$scope.selectedConfigIndex].blocksList[$scope.selectedBlockIndex];
        block.deleteCommand(index);
        if(index <= $scope.selectedCommandIndex) {
            if($scope.configurationList[$scope.selectedConfigIndex].blocksList[$scope.selectedBlockIndex].commands[$scope.selectedCommandIndex -1]) {
                $scope.changeSelectedCommand($scope.selectedCommandIndex - 1);
            } else if($scope.configurationList[$scope.selectedConfigIndex].blocksList[$scope.selectedBlockIndex].commands[$scope.selectedCommandIndex]) {
                $scope.changeSelectedCommand($scope.selectedCommandIndex);
            } else if($scope.configurationList[$scope.selectedConfigIndex].blocksList[$scope.selectedBlockIndex].commands[$scope.selectedCommandIndex+1]) {
                $scope.changeSelectedCommand($scope.selectedCommandIndex + 1);
            } else {
                $scope.selectedCommandIndex = null;
            }
        }
        event.stopPropagation();
    }

    $scope.moveConfiguration = function(currentIndx, targetIndx) {
        binary.swapConfiguration(currentIndx, targetIndx);
        if(currentIndx === $scope.selectedConfigIndex) {
            $scope.changeSelectedConfig(targetIndx);
        } else if(targetIndx === $scope.selectedConfigIndex) {
            $scope.changeSelectedConfig(currentIndx);
        }
    }

    function clearBlick() {
        $scope.blinkSelectedConfig = false;
        $scope.blinkSelectedBlock = false;
        $scope.blinkSelectedCommand = false;
    }

    function pointToError(result) {
        if(result.configIndx !== undefined) {
            $scope.changeSelectedConfig(result.configIndx)
            $scope.blinkSelectedConfig = true;
        }
        if(result.blockIndx !== undefined) {
            $scope.changeSelectedBlock(result.blockIndx);
            $scope.blinkSelectedConfig = false;
            $scope.blinkSelectedBlock = true;
        }
        if(result.commandIndx !== undefined) {
            $scope.changeSelectedCommand(result.commandIndx);
            $scope.blinkSelectedConfig = false;
            $scope.blinkSelectedBlock = false;
            $scope.blinkSelectedCommand = true;
        }
        $timeout(clearBlick, 3000);
    }

    function _createBin() {
        var deferred = $q.defer();
        $timeout(function() {
            var result = binary.isValid();
            if(!result.isValid) {
                pointToError(result);
                deferred.reject(result.error);
                return;
            }
            var data = binary.toBinary();
            var binFilePath = path.join($scope.binOutputConfig.binFileFolderPath, $scope.binOutputConfig.binFileName + '.bin');
            fs.writeFile(binFilePath, data, function(err) {
                if(err){
                    if(err.code === 'EBUSY') {
                        deferred.reject("Error in opening the file. The file is already opened in some other application");
                    }
                    else {
                        deferred.reject(err.toString());
                    }
                }                
                else
                    deferred.resolve();
            });
        });
        return deferred.promise;
    }

    $scope.createBinary = function() {
        $rootScope.setLoadingProgress(true);
        if($scope.selectedDeviceType === "Integrated") {
            $scope.generateBinary()
            .then(function() {
                StatusMessageService.success("Binary File Created Successfully");
            }, function(err){
                StatusMessageService.error(err, 10000);
            }).finally(function() {
                $rootScope.setLoadingProgress(false);
            });
        } else {
            _createBin()
            .then(function() {
                StatusMessageService.success("Binary File Created Successfully");
            }, function(err){
                StatusMessageService.error(err, 10000);
            }).finally(function() {
                $rootScope.setLoadingProgress(false);
            });
        }
        
    }
    

    $scope.appendDeviceNameToBlock = function() {        
        var selectedBlock =  $scope.configurationList[$scope.selectedConfigIndex].blocksList[$scope.selectedBlockIndex];
        var selectedDevice = selectedBlock.deviceName;
        if(selectedBlock.blockType !== '') {
            var blockType = selectedBlock.blockType;         
            if(selectedDevice.toLowerCase() === 'common') {
                selectedBlock.blockName = blockType + ' - Common';
            } else if(selectedDevice !== ''){
                selectedBlock.blockName = blockType + ' - ' + selectedDevice.split('-')[0].trim();
            } else {
                selectedBlock.blockName = blockType;
            }
        }
    }

    $scope.changeBlockDevice = function() { 
        disableMaskOrNot();          
        var selectedBlock =  $scope.configurationList[$scope.selectedConfigIndex].blocksList[$scope.selectedBlockIndex];        
        var selectedDevice = selectedBlock.deviceName;
        selectedBlock.deviceValue = $scope.availableAmps.indexOf(selectedDevice);
        $scope.appendDeviceNameToBlock();
    }

    $scope.showWarningPopUp = function() {
        $scope.warningPopUp = true;
    }

    $scope.closeWarningPopUp = function() {
        $scope.warningPopUp = false;
    }

    $scope.gotoHardwareConfigPage = function() {
        $scope.closeWarningPopUp();
        $location.path("/homepage");
    }

    $scope.setDirectoryPath = function(value) {
        if(value.files[0] && value.files[0].path) {
            $scope.binOutputConfig.binFileFolderName = path.basename(value.files[0].path);
            console.log($scope.binOutputConfig.binFileFolderName);
            $scope.binOutputConfig.binFileFolderPath = value.files[0].path;
            window.localStorage.setItem("NON_INTEG-binFileFolderPath", $scope.binOutputConfig.binFileFolderPath);
        }
        $scope.$digest();
    };

    $scope.setCfgDirectoryPath = function(value) {
        if(value.files[0] && value.files[0].path) {
            $scope.cfgFileName = path.basename(value.files[0].path);
            console.log($scope.cfgFileName);
            $scope.cfgFilePath = value.files[0].path;
            window.localStorage.setItem("NON_INTEG-cfgFilePath", $scope.cfgFilePath);
        }
        $scope.$digest();
    };

    $scope.initializeWorkingDirectory = function() {
        var fs = require('fs');
        var folder = window.localStorage.getItem("NON_INTEG-binFileFolderPath");
        if(folder != null && folder != undefined && fs.existsSync(folder)) {
            $scope.binOutputConfig.binFileFolderPath = folder;
        } else {
            $scope.binOutputConfig.binFileFolderPath = '';
        }
    }

    var devWriteCmds = {
        "Tuning Mode": {
            DEV_A_MAIN: {
                data: null,
                description: "Base Image For Device- TAS2563, Program - Tuning Mode",
                name: "TuningMode Program"
            },
            application: 1,
            iSensePd: 1,
            pos: 0,
            type: "program",
            vSensePd: 1 
        },
        "configuration": {
            DEV_A_COEFF: {
                data: null,
                description: "Snapshot 1 - 48 KHz - Tuning Mode",
                name: "Snapshot 1"
            },
            DEV_A_PRE: {
                data: null,
                description: "Snapshot 1 - 48 KHz - Tuning Mode",
                name: "Snapshot 1"
            },
            clockFrequency: 0,
            clockSource: "BCLK",
            configName: "ddc",
            devices: 1,
            pll: "0_pll_Tuning Mode_48 KHz_Auto",
            pos: 0,
            program: "Tuning Mode",
            sampleRate: 48000,
            sbclkFsRatio: 0,
            snapshotName: "Snapshot 1",
            type: "configuration"
        },
        "calibration": {
            DEV_A_COEFF: {
                data: null,
                description: "Calibration Snapshot 1 - 48 KHz - Tuning Mode",
                name: "Snapshot 1 - Calibration"
            },
            DEV_A_PRE: {
                data: null,
                description: "Calibration Snapshot 1 - 48 KHz - Tuning Mode",
                name: "Snapshot 1 - Calibration"
            },
            clockFrequency: 0,
            clockSource: "BCLK",
            configName: "ddc",
            devices: 1,
            pll: "0_pll_Tuning Mode_48 KHz_Auto",
            pos: 1,
            program: "Tuning Mode",
            sampleRate: 48000,
            sbclkFsRatio: 0,
            snapshotName: "Snapshot 1",
            type: "configuration"
        }
    };
    var headersConfig = {
        ddcName: "ddc",
        version: "1.3.5",
        magicNumber: '35353532',
        description: 'TI SmartAmp',
        device: "TAS2783_Mono",
        deviceFamily: "microCDSP",
        dspFirmwareVersion: "1.1.0.0",
        driverFirmwareVersion: "2.2",
    };

    var sysIntegData = {
        binaryFormat: "kernel.org",
        maxPrograms: 5,
        maxConfigurations: 10,
        binaryFormatVersion: "2.9",
        endSystemAudioModes: {},
        devOrientation: endSystemOptions.devOrientation,
        numberOfDevices: 1
    };
    var folderPath = {
        "bin": null
    };

    endSystemOptions.devOrientation.forEach(function(orient) {
        sysIntegData.endSystemAudioModes[orient] = endSystemOptions.windowsAudioModes.map(function(audioMode) {
            return {"name": audioMode, config:"Not supported"};
        });
    });

    sysIntegData.endSystemAudioModes["Portrait"].forEach(function(audioMode) {
        audioMode.config = "Tuning Mode-ddc-Snapshot 1";
    });

    function formatCfgData(dataStr) {
        return dataStr.split('\n')
        .filter(function(lineVal) {
            return lineVal.substr(0,1) != '' &&
                lineVal.substr(0,1) != '#' &&
                lineVal.substr(0,1) != 'r' &&
                lineVal.substr(0,1) != 'i' &&
                lineVal.substr(0,1) != 'd';
        }).join('\n');
    }

    function updateChecksumConfig() {
        var defer = $q.defer();
        defer.resolve();
        return defer.promise;
     }

    $scope.generateBinary = function() {
        if($scope.cfgFileName.match(/([^\s]+(\.(cfg))$)/gi) === null) {
            StatusMessageService.error("Invalid file type selected.I2C checksum calculation load supports only .cfg files");
            return;
        }
        var Block_V2 = $injector.get('Block_V2');
        return updateChecksumConfig().then(function(){
            return fileOps.readFile($scope.cfgFilePath)
            .then(function(data) {
                Checksum_V2.checkForSlave = true;
                Checksum_V2.checksumSlave = parseInt($scope.checksumSlave);
                var cfgData = formatCfgData(data);
                var slave = cfgData.split('\n')[0].split(' ')[1];
                var dummyCmd = 'w' + ' ' + slave + ' 00 00';
                var programBlk = new Block_V2(cfgData, 2), 
                    configBlk_coeff = new Block_V2(dummyCmd, 18),
                    configBlk_pre = new Block_V2(dummyCmd, 34);

                sysIntegData.numberOfDevices = Number(configDataService.getSettings()['noOfDevices'].split(" ")[0]);
                devWriteCmds['Tuning Mode'].DEV_A_MAIN.data = programBlk;
                devWriteCmds.configuration.DEV_A_COEFF.data = configBlk_coeff;
                devWriteCmds.configuration.DEV_A_PRE.data = configBlk_pre;
                devWriteCmds.calibration.DEV_A_COEFF.data = configBlk_coeff;
                devWriteCmds.calibration.DEV_A_PRE.data = configBlk_pre;
                return binaryDump.createJso(devWriteCmds, headersConfig, 2, sysIntegData);
            })
            .then(function(data) {
                
                folderPath.bin = path.join($scope.binOutputConfig.binFileFolderPath, $scope.binOutputConfig.binFileName);
                return binaryDump.createBinFromDumps(data.binDumps, folderPath, 2, sysIntegData);
            })
            // .then(function() {
            //     StatusMessageService.success("Binary file created Successfully");
            // })
            // .catch(function(Err){
            //     StatusMessageService.error("Error occured: " + Err);
            // })
        });
    }

    $scope.initializeWorkingDirectory();
    init();
    $rootScope.$on('newSession', function(){
        $scope.gotoHardwareConfigPage();
    });
    $rootScope.$on('appReload', function(){
        $location.path("/homepage");
    });
});