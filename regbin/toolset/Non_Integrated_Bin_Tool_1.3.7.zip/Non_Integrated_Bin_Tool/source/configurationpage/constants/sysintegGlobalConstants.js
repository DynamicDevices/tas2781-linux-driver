mainApp.constant('blockType', {
    "PLL": "0x00",
    "DEV_A_MAIN": "0x01",
    "DEV_A_COEFF": "0x03",
    "DEV_A_PRE": "0x04",
    "POST_POWER_UP": "0x06",
    "DEV_A_POST_POWER_UP": "0x07",
    "DEV_B_MAIN": "0x08",
    "DEV_B_COEFF": "0x0a",
    "DEV_B_PRE": "0x0b",
    "DEV_B_POST_POWER_UP": "0x0e",
    "DEV_C_MAIN": "0x10",
    "DEV_C_COEFF": "0x11",
    "DEV_C_PRE": "0x12",
    "DEV_C_POST_POWER_UP": "0x13",
    "DEV_D_MAIN": "0x14",
    "DEV_D_COEFF": "0x15",
    "DEV_D_PRE": "0x16",
    "DEV_D_POST_POWER_UP": "0x17",
    "MAIN_ALL_DEVICES": "0x0d"
});
mainApp.constant('KernelblockType', {
    "PLL": "0x00",
    "DEV_A_MAIN": "0x02",
    "DEV_A_COEFF": "0x12",
    "DEV_A_PRE": "0x22",
    "POST_POWER_UP": "0x31",
    "DEV_A_POST_POWER_UP": "0x32",
    "DEV_B_MAIN": "0x03",
    "DEV_B_COEFF": "0x13",
    "DEV_B_PRE": "0x23",
    "DEV_B_POST_POWER_UP": "0x33",
    "DEV_C_MAIN": "0x04",
    "DEV_C_COEFF": "0x14",
    "DEV_C_PRE": "0x24",
    "DEV_C_POST_POWER_UP": "0x34",
    "DEV_D_MAIN": "0x05",
    "DEV_D_COEFF": "0x15",
    "DEV_D_PRE": "0x25",
    "DEV_D_POST_POWER_UP": "0x35",
    "MAIN_ALL_DEVICES": "0x01"
})

mainApp.constant('regDumpHexStrConst', {
    book: '0x7f',
    page: '0x00',
    burst: '0x85',
    delay: '0x81'
});

mainApp.constant('binConstants', {
    'application': {
        'ROM Mode': 0,
        'Tuning Mode': 1,
    }
});

mainApp.constant('binConfigFileNames', {
    "1.1": "binConfig.json",
    "2.1.1": "binConfig_V2.json",
    "3.0": "binConfig_quad.json",
    "2.3.0": "binConfig_V2_quad.json"
})
 