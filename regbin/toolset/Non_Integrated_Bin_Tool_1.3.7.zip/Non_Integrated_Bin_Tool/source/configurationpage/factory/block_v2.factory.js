mainApp.factory('Block_V2', ['Checksum_V2', 'Bpod', 'KernelblockType',
function(Checksum_V2, Bpod, KernelblockType) {

    'use strict';

    var eol = require('os').EOL;
    var path = require('path');
    var cfgParser = require(path.join(process.cwd() + '/source/js/readcfg'));

    // It is possible that the enum cmds will vary from tascom.
    // However since it is same at the moment, we use tascom's object.
    //
    // In the futrue if it varies, (For eg. comments also needs to be parsed)
    // we can update it here.
    var cmds = {
        DELAY:  (254),
        BURST:  (253),
        SET  :  (252),
        WAIT :  (251),
        SLAVE:  (250),
        READ:   (249),
        BREAK:  (248),
        GPIO:	(247),
        XMOS:	(246)
    };

    var subBlockType = {
        WRITE: toBytesInt16(1),
        BURST: toBytesInt16(2),
        DELAY: toBytesInt16(3)
    }
    var binCmds = {
        CMD_BURST: 0x85,
        CMD_DELAY: 0x81
    }

    var blockTypes = KernelblockType, segregatedBlockType = {}; 
    
    function segregateBlockType() {
        var segBlockType = { "deviceA" : [], "deviceB" : [],"deviceC" : [], "deviceD" : [], "common" : []};
      for (var key in blockTypes) {
        if(key.indexOf('_A_') !== -1) {
            segBlockType.deviceA.push(blockTypes[key]);
        }
        else if(key.indexOf('_B_') !== -1) {
            segBlockType.deviceB.push(blockTypes[key]);
        }
        else if(key.indexOf('_C_') !== -1) {
            segBlockType.deviceC.push(blockTypes[key]);
        }
        else if(key.indexOf('_D_') !== -1) {
            segBlockType.deviceD.push(blockTypes[key]);
        }
        else {
          segBlockType.common.push(blockTypes[key]);
        }
      }
      return segBlockType;
    }
    
    segregatedBlockType = segregateBlockType();
    
    function hexString(num) {
        return ((num < 16) ? '0' : '') + num.toString(16);
    }

    function cfgWrite(slave, command, burstLength) {

        if (command.length === 2) {
            return 'w ' +
                hexString(slave) + ' ' +
                command.map(hexString).join(' ');
        }

        return 'w ' +
            hexString(slave) + ' ' +
            hexString(command[2]) + ' ' +
            command[3].map(hexString).join(eol + '> ');
    }

    function cfgDelay(command) {
        return 'd ' + hexString(command[1]);
    }

    function cfgRead(slave, command) {
        return 'r ' +
            hexString(slave) + ' ' +
            hexString(command[1]) + ' '
            hexString(command[2]);
    }

    function cfgCommand(slave, command, options) {
        switch(command[0]) {
            case cmds.BURST :    
                return cfgWrite(slave, command, options.burstLength);
            case cmds.READ :
                return cfgRead(slave, command);
            case cmds.DELAY :
                return cfgDelay(command);
            default:
                return cfgWrite(slave, command);
        }
    }

    function toBytesInt16(num) {
        return [
             (num & 0xff00) >> 8,
             (num & 0xff),
        ];
    }

    function toBytesInt32(num) {
        return [
             (num & 0xff000000) >> 24,
             (num & 0x00ff0000) >> 16,
             (num & 0x0000ff00) >> 8,
             (num & 0x000000ff),
        ];
    }

    function toInt(bytes) {
        var value = 0;
        for (var i=0; i<bytes.length; i++) {
            value = (value * 256) + bytes[i];
        }

        return value;
    }

    function bookPageUpdates(bookPage, offset, values) {
        if (bookPage.page === 0 && offset === 127) {
            bookPage.book = values.shift();
        }

        if (offset === 0) {
            bookPage.page = values.shift();
        }
    }

    function pushSingleWriteSubBlock(data){
        data.bin = data.bin.concat(subBlockType.WRITE)
                        .concat(toBytesInt16(data.subBlockLength)) //the actual length
                        .concat(data.subBlock);
        data.subBlock = [];
        data.subBlockLength = 0;
        data.subBlockCount++;
        return data;
    }

    function binBurst(bookPage, offset, values, data) {
        var singleWrites =[], actualLength= values.length;
        if(values.length%4){
            actualLength = parseInt(values.length/4)*4
            singleWrites = values.splice(parseInt(values.length/4)*4);
        }
        var burst = 
            subBlockType.BURST
            .concat(toBytesInt16(actualLength))
            .concat([bookPage.book, bookPage.page, offset, 0])
            .concat(values);
        data.subBlockCount++;
        data.bin = data.bin.concat(burst);
        for(var i=0;i<singleWrites.length;i++){ //write the extra writes as single byte writes
            data = binSingleWrite(bookPage.book, bookPage.page, offset+actualLength+i, data);
        }
        return data;
    }

    function binSingleWrite(bookPage, offset, value, data) {
        data.subBlock = data.subBlock.concat( [bookPage.book, bookPage.page, offset, value]);
        data.subBlockLength++;
        return data;
    }


    function binWrite(command, bookPage, data) {
        var offset;
        var values;
        var ret = {};

        if (command.length === 2) {
            offset = command[0];
            values = [command[1]];
        } else {
            offset = command[2];
            values = command[3].slice();
        }

        bookPageUpdates(bookPage, offset, values);

        switch(values.length) {
            case 0:
                return data;
            case 1:
                return binSingleWrite(bookPage, offset, values[0], data);
            default:
                if(data.subBlock.length){
                    data = pushSingleWriteSubBlock(data);
                }
                return binBurst(bookPage, offset, values, data);
        }
    }

    function binCommand(command, bookPage, data) {
        switch(command[0]) {
            case cmds.SLAVE:
            case cmds.READ:
                return data;
            case cmds.DELAY:
                if(data.subBlock.length){
                    data = pushSingleWriteSubBlock(data);
                }
                data.bin = data.bin.concat(subBlockType.DELAY.concat(toBytesInt16(command[1])));
                data.subBlockCount++;
                return data;
            default:
                return binWrite(command, bookPage, data);
        }
    }

    function toDelay(bin) {
        var ret ={};
        ret = {};
        ret.subBlock = {};
        ret.subBlock.type = 0x03;
        bin.splice(0, 2);
        var value = toInt(bin.splice(0, 2));
        ret.subBlock.delay = value;
        ret.commands = [cmds.DELAY, value];
        return ret;
    }

    function bookPageSwitches(bookPage, book, page) {
        var cmds = [];

        if (bookPage.book !== book) {
            cmds = cmds.concat([[0, 0],
                [127, book],
            ]);

            if (page !== 0) {
                cmds.push([0, page]);
            }
        } else if (bookPage.page !== page) {
            cmds.push([0, page]);
        }

        bookPage.book = book;
        bookPage.page = page;

        return cmds;
    }

    function toBurstWrite(bin, bookPage, slave) {
        bin.splice(0, 2);
        var length = toInt(bin.splice(0, 2));
        var ret ={};
        ret.subBlock = {};
        ret.subBlock.type = 0x02;
        ret.subBlock.length = length;
        ret.subBlock.data = {
            slave: slave,
            book: bin.shift(),
            page: bin.shift(),
            offset: bin.shift(),
            values: bin.splice(0, length+1).splice(1,length),
        };
        ret.commands = toWrite(ret.subBlock.data, bookPage);

        while (bin.length % 4) {
            console.error("burst length is not a multiple of 4","color:red");
        }

        return ret;
    }

    function toSingleWrite(bin, bookPage, slave) {
        bin.splice(0, 2);
        var length = toInt(bin.splice(0, 2));
        var commands = [];
        var ret ={};
        ret.subBlock = {};
        ret.subBlock.type = 0x01;
        ret.subBlock.length = length;
        ret.subBlock.data = [];
        for(var i=0;i<length;i++){
            var data = {
                slave: slave,
                book: bin.shift(),
                page: bin.shift(),
                offset: bin.shift(),
                values: [bin.shift()],
            };
            commands = commands.concat(toWrite(data, bookPage));
            ret.subBlock.data.push(data);
        }
        ret.commands = commands;
        return ret;
    }

    function toWrite(data, bookPage) {
        var commands = [[cmds.SLAVE, data.slave]]
            .concat(bookPageSwitches(bookPage, data.book, data.page));

        if (data.values.length === 1) {
            commands.push([data.offset, data.values[0]]);
        } else {
            commands.push([cmds.BURST, 
                data.values.length, 
                data.offset, 
                data.values]);
        }

        return commands;
    }


    function toCommands(bin, slave) {
        var commands = [];
        var bookPage = {}, ret={};
        var subBlocks = [], parsed;
        var noOfSubBlocks = toInt(bin.splice(0,4));
        for(var n=0;n<noOfSubBlocks;n++) {
            console.log('\nBinSize in block read :SubblockIndex - ',n,'BinSize-',bin.length
            );
            switch(bin[1]) {
                case toInt(subBlockType.DELAY):
                    parsed = toDelay(bin);
                    commands.push(parsed.commands);
                    break;
                case toInt(subBlockType.BURST):
                    parsed = toBurstWrite(bin, bookPage, slave);
                    commands = commands.concat(parsed.commands);
                    break;
                default:
                    parsed = toSingleWrite(bin, bookPage, slave);
                    commands = commands.concat(parsed.commands);
                    break;
            }
            
            subBlocks.push(parsed.subBlock);
        }
        ret.commands = commands;
        ret.subBlocks = subBlocks;
        return ret;
    }

    function findSlave(cfgSlave, slave) {
        if (!slave) {
            return cfgSlave;
        }

        if (!isNaN(slave)) {
            return slave;
        }

        return slave[cfgSlave];
    }

    function limitBurstLength(command, burstLength) {
        var bursts = [];
        for (var i=0; i<command[3].length; i+=burstLength) {
            var writes = command[3].slice(i, i + burstLength);
            var offset = command[2] + i;
            bursts.push([cmds.BURST, writes.length, offset, writes]);
        }

        return bursts;
    }

    function fixBurstCommands(commands) {
        return commands.map(function (command) {
            if(command[0] === cmds.BURST) {
                command[3].length = command[1];
            }
            return command;
        });
    }

    function Block_V2(input, blockType, checksum, parsed) {
        this.blockType = blockType || 0;
        this.checksum = checksum;

        if (Array.isArray(input)) {
            this.commands = input;
        } else if (typeof input === 'string') {
            this.commands = cfgParser.parse(input);
        }
        if(parsed){
            this.subBlocks = parsed;
        }
        this.commands = fixBurstCommands(this.commands);
    };

    Block_V2.cmds = cmds;

    Block_V2.prototype.cfg = function(options) {

        options = options || {};
        options.burstLength = options.burstLength || 128;

        if (!this.commands || !this.commands.length) {
            return '';
        }

        var cmdSlave = 0;
        return this.commands.reduce(function(cfgLines, command) {

            if (command[0] === cmds.SLAVE) {
                cmdSlave = findSlave(command[1], options.slave);
                return cfgLines;
            }
            
            var newLines = cfgCommand(cmdSlave, command, options);

            if (!Array.isArray(newLines)) {
                newLines = [newLines];
            } 

            return cfgLines.concat(newLines);
        }, []).join(eol) + eol;
    };

    function getChecksumRow(commands, deviceIndex) {
        var blockChecksum = new Checksum_V2(commands);
        var pramChecksum = blockChecksum.pramChecksum(deviceIndex);
        var yramChecksum = blockChecksum.yramChecksum(deviceIndex);

        return [
            Number(pramChecksum >= 0),
            pramChecksum || 0,
            Number(yramChecksum >= 0),
            yramChecksum || 0,
        ];
    }

    function toHexString(num) {
      var hexString = num.toString(16);
      if(num < 16) {
        return "0" + hexString;
      }
      return hexString;
    }

    Block_V2.prototype.getChecksumData = function(devIndex) {
        var blockBpod = new Bpod(this.commands);
        return getChecksumRow(blockBpod.commands, devIndex)
    }

    Block_V2.prototype.toJSON = function () {
        var blockJSONObj = {};
        blockJSONObj.blockType = '0x' + toHexString(this.blockType);
        blockJSONObj.checksum = splitChecksumBytes(this.checksum);
        blockJSONObj.subBlocks = this.subBlocks;
        return blockJSONObj;
    }

    function splitChecksumBytes(checksumDec) {
        var checksumHex, checksumObj = {};
        checksumHex = toHexString(checksumDec);
        for(var i=checksumHex.length;i<8;i++){
            checksumHex = "0" + checksumHex;
        }
        checksumObj.isPramAvailable = checksumHex.slice(0,2);
        checksumObj.pramChecksum = checksumHex.slice(2,4);
        checksumObj.isYramAvailable = checksumHex.slice(4,6);
        checksumObj.yramChecksum = checksumHex.slice(6,8);
        return checksumObj;
    }

    function createSubBlockBin(commands, bookPage){
        var data = {subBlockCount : 0, bin : [], subBlock : [], subBlockLength : 0};
        for( var i=0; i<commands.length; i++){
           data = binCommand(commands[i], bookPage, data);
        }
        if(data.subBlock.length){
            data = pushSingleWriteSubBlock(data);
        }
        return data;
    }
    Block_V2.prototype.binary = function() {

        if (!this.commands || !this.commands.length) {
            return [];
        }

        // TODO :Validate that the block contains only one slave
        // WARNING: If block contains multiple slaves, then book and page
        // will conflict across writes since we are not caching book and page
        // at slave level

        var bookPage = {
            book: 0,
            page: 0
        }

        var blockBpod = new Bpod(this.commands);
        var deviceIndex = getDeviceIndex(this.blockType);
        var checksumRow = getChecksumRow(blockBpod.commands, deviceIndex);
        var data = createSubBlockBin(this.commands, bookPage);
        return toBytesInt32(this.blockType)
            .concat(checksumRow)
            .concat(toBytesInt32(data.bin.length))
            .concat(toBytesInt32(data.subBlockCount))
            .concat(data.bin);
    };

    function getDeviceIndex(blockType) {
        var deviceIndex;
        for(var key in segregatedBlockType) {
          if(segregatedBlockType[key].indexOf('0x' + hexString(blockType)) !== -1) {
              switch(key){
                  case "deviceB":
                      deviceIndex = 1;
                      break;
                  case "deviceC":
                      deviceIndex = 2;
                      break;
                  case "deviceD":
                      deviceIndex = 3;
                      break;
                  default:
                      deviceIndex = 0;
              }
          }
        }
        return deviceIndex
      }

    Block_V2.prototype.limitBurst = function(burstLength) {
        var commands = [];

        this.commands.forEach(function(command) {
            if (command[0] === cmds.BURST) {
                commands = commands.concat(limitBurstLength(command, burstLength));
            } else {
                commands.push(command);
            }
        });

        return new Block_V2(commands);
    };

    Block_V2.prototype.concat = function(block) {
        return new Block_V2(this.commands.concat(block.commands));
    };

    Block_V2.prototype.setSlave = function(slave) {
        return new Block_V2(this.commands.map(function(command) {
            command = command.slice();
            if (command[0] === cmds.SLAVE) {
                command[1] = findSlave(command[1], slave);
            }

            return command;
        }));
    };

    Block_V2.fromBinary = function(bin, blockType, checksum, slave) {
        slave = slave || 0;
        var inptSize = bin.length;
        var blk = {};
        var parsed = toCommands(bin, slave);
        blk.dta = new Block_V2(parsed.commands, blockType, checksum, parsed.subBlocks);
        blk.len = inptSize - bin.length;
        return blk;
    };

    function getHeaderPrefix(fileName) {
        return [
            "#ifndef __" +fileName.toUpperCase()+"_H__",
            "#define __" +fileName.toUpperCase()+"_H__",
            "/* typedef unsigned char cfg_u8;",
            "typedef union {",
            "    struct {",
            "        cfg_u8 offset;",
            "        cfg_u8 value;",
            "    };",
            "    struct {",
            "        cfg_u8 command;",
            "        cfg_u8 param;",
            "    };",
            "} cfg_reg;",
            "",
            "#define CFG_META_SWITCH (255)",
            "#define CFG_META_DELAY  (254)",
            "#define CFG_META_BURST  (253) */",
            "",
            "/* Example C code */",
            "/*",
            "    // Externally implemented function that can write n-bytes to the device",
            "    // PCM51xx and TAS5766 targets require the high bit (0x80) of the I2C register to be set on multiple writes.",
            "    // Refer to the device data sheet for more information.",
            "    extern int i2c_write(unsigned char *data, int n);",
            "    // Externally implemented function that delays execution by n milliseconds",
            "    extern int delay(int n);",
            "    // Example implementation.  Call like:",
            "    //     transmit_registers(registers, sizeof(registers)/sizeof(registers[0]));",
            "    void transmit_registers(cfg_reg *r, int n)",
            "    {",
            "        int i = 0;",
            "        while (i < n) {",
            "            switch (r[i].command) {",
            "            case CFG_META_SWITCH:",
            "                // Used in legacy applications.  Ignored here.",
            "                break;",
            "            case CFG_META_DELAY:",
            "                delay(r[i].param);",
            "                break;",
            "            case CFG_META_BURST:",
            "                i2c_write((unsigned char *)&r[i+1], r[i].param);",
            "                i +=  (r[i].param / 2) + 1;",
            "                break;",
            "            default:",
            "                i2c_write((unsigned char *)&r[i], 1);",
            "                break;",
            "            }",
            "            i++;",
            "        }",
            "    }",
            "*/",
            "",
            "cfg_reg "+fileName+"_registers[] = {"
        ];
    }

    function getHeaderSuffix() {
        return ["};"];
    }

    function headerDelay(cmd) {
        return "{ CFG_META_DELAY, " + cmd[1] + " },";
    }

    function headerSingleWrite(value1, value2) {
        return "{ 0x" + hexString(value1) + ", 0x" + hexString(value2) + " },";
    }

    function headerWrite(cmd) {
        var burstValues, lines = [];

        // single write
        if (cmd.length === 2) {
            return headerSingleWrite(cmd[0], cmd[1]);
        }

        // burst
        burstValues = cmd[3].slice();
        burstValues.unshift(cmd[2]);

        if ((burstValues.length %2) !== 0) {
            burstValues.push(0);
        }

        lines.push("{ CFG_META_BURST, " + cmd[1] + " },");
        while(burstValues.length) {
            lines.push(
                headerSingleWrite(burstValues.shift(), burstValues.shift())
            );
        }

        return lines;
    }

    function headerCommand(command) {
        switch(command[0]) {
            case cmds.BURST:
                return headerWrite(command);
            case cmds.DELAY:
                return headerDelay(command);
            case cmds.SLAVE:
            case cmds.READ:
                /*SLAVE and READ is not supported in header file format*/
                return '';
            default:
                return headerWrite(command);
        }
    }

    Block_V2.prototype.header = function (fileName) {
        var headerLines;
        var headerPrefix = getHeaderPrefix(fileName);
        var headerSuffix = getHeaderSuffix();

        if (!this.commands || !this.commands.length) {
            return '';
        }

        headerLines = this.commands.reduce(function (acc, command) {
            var headerLines;

            if (command[0] === cmds.SLAVE) {
                // SLAVE is not supported in .h file format
                return acc;
            }

            headerLines = headerCommand(command);
            if (!Array.isArray(headerLines)) {
                headerLines = [headerLines];
            }

            return acc.concat(headerLines);
        }, []);

        headerLines = headerLines.map(function(line) {
            return "    "+ line;
        });
        headerLines = headerPrefix.concat(headerLines).concat(headerSuffix);

        return headerLines.join(eol) + eol + "#endif";
    };

    return Block_V2;
}]);
