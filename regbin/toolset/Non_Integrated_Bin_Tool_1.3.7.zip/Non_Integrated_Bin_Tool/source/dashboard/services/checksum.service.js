mainApp.service('checksumService', function($q, binaryDump, Bpod, Checksum) {
    var PRAMChecksumConfig;

    var self = this;

    var getPRAMConfig = function(){
        var deviceIndex = deviceInfo.selectedDevice;
        if(!PRAMChecksumConfig){
            PRAMChecksumConfig = hybridFlowConfig.getPRAMChecksumConfiguration();
        }
        return PRAMChecksumConfig[deviceIndex];
    }
    function calculateChecksum(values, seed) {
        var checksum = seed || 0;

        for (var i=0; i<values.length; i++) {
            checksum = getChecksum([checksum, values[i]]);
        }

        return checksum;
    }

    function getChecksum(registerArray){
        var size_input,
            initial_state = [], cipher_temp = [],
            checksum_int =[];

        // Function to convert int array to byte array
        var intToByte = function(n){
            if (n < 0 || n > 255 || n % 1 !== 0) {
                throw new Error(n + " does not fit in a byte");
            }
            var bytearrayString=("000000000" + n.toString(2)).substr(-8)
            return (bytearrayString.split('').map(Number));
        }

        for (var cnt= 0; cnt < registerArray.length; cnt ++){
            cipher_temp.push(intToByte(registerArray[cnt]));
        }

        // Implement the Checksum Function
        size_input = cipher_temp.length;

        for(var i = 0; i<16 ; i ++){
            initial_state[i]=0;
        }

        for (var loop_index = 0; loop_index < size_input; loop_index++){
            for (var cnt =0; cnt< 8; cnt ++){
                initial_state[cnt]= cipher_temp[loop_index][cnt];
            }

            for (var i =0; i < 8; i++){
                if(initial_state[i]==1){
                    initial_state[i]= +!(initial_state[i]);
                    initial_state[i+6]= +!(initial_state[i+6]);
                    initial_state[i+7]= +!(initial_state[i+7]);
                    initial_state[i+8]= +!(initial_state[i+8]);
                }
            }

           checksum_int.push(initial_state.slice(8,16));

        }

        if (checksum_int.length > 0) {
            return parseInt(checksum_int[size_input-1].reduce(function(preVal, val){
                return preVal+val.toString();
            }, ""), 2);
        } else {
            return 0;
        }

    }
    function getBytesFromDDF (ddfStr, options) {
      return ddfDumpService.dumpDdf(ddfStr, options)
      .then(function(block) {
          var bpodCommands = new Bpod(block.commands);
          var blockChecksum = new Checksum(bpodCommands.commands);
          return blockChecksum.bpodCommands
     });
    }
    this.calculateChecksum = calculateChecksum;

    this.getPRAMChecksum = function(){
        var PRAMConfig = getPRAMConfig();
        if(PRAMConfig){
            var path = require('path');
            var dregs = DeviceManagerService.getDregs(),
                isconnected = dregs.connected;
            var device = DeviceManagerService.getDevice(deviceInfo.selectedDevice);
            var ddfPath = path.join(DeviceManagerService.getPluginPath(), PRAMConfig.registers);
            var dumpOptions = {
                burst: 128,
                dumpFormatFile: ddfPath,
                device: DeviceManagerService.getSelectedDeviceName(),
                slave: device.regmodel.slave
            };

            dregs.connected = false;
            var ddfStr = fs.readFileSync(dumpOptions.dumpFormatFile,'utf8')
            return getBytesFromDDF(ddfStr,dumpOptions)
            .then(function(dumpData){
                var registers = dumpData.reduce(function(prevVal, val){
                  if(val.data) {
                      return prevVal.concat(val.data);
                  }
                  else{
                      return prevVal;
                  }
                   }, []);
                dregs.connected = isconnected;
                return self.calculateChecksum(registers);
            });
        }
        else{
            return $q.when(0);
        }
    };
});
