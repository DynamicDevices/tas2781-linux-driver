mainApp.service('StatusMessageService', ['$rootScope', '$timeout', function ($rootScope, $timeout) {
    //    'use strict';
    
        var statusInformation = {};
        var deferredTimer;
    
        statusInformation.statusQueue = []; // Status object queue
        statusInformation.statusInterval = 10; // Duration for which the status should be visible
        statusInformation.statusUpdate = false; // handle to check if the status update is in progress
        
        statusInformation.statusConstants = {}; // handle to store the status types and assign display colors and interval for each type
        statusInformation.statusConstants.ERROR = {};
        statusInformation.statusConstants.WARNING = {};
        statusInformation.statusConstants.SUCCESS = {};
        statusInformation.statusConstants.INFORMATION = {};
    
        statusInformation.statusConstants.ERROR.BACKGROUND = '#FCD3C1';
        statusInformation.statusConstants.WARNING.BACKGROUND = '#FBEEA3';
        statusInformation.statusConstants.SUCCESS.BACKGROUND = '#D7ECDD';
        statusInformation.statusConstants.INFORMATION.BACKGROUND = '#C8DAE3';
    
        statusInformation.statusConstants.ERROR.BORDER = '#CC0000';
        statusInformation.statusConstants.WARNING.BORDER = '#f3cc35';
        statusInformation.statusConstants.SUCCESS.BORDER = '#329b46';
        statusInformation.statusConstants.INFORMATION.BORDER = '#115566';
    
        statusInformation.statusConstants.ERROR.ICON = '../assets/snackbar-error.png';
        statusInformation.statusConstants.WARNING.ICON = '../assets/snackbar-warning.png';
        statusInformation.statusConstants.SUCCESS.ICON = '../assets/snackbar-success.png';
        statusInformation.statusConstants.INFORMATION.ICON = '../assets/snackbar-info.png';
        
        statusInformation.statusConstants.errorInterval = 50;
        statusInformation.statusConstants.warningInterval = 50;
        statusInformation.statusConstants.successInterval = 50;
        statusInformation.statusConstants.informationInterval = 10;
    
        var showTime;
            
        // ----- functions to update the status types. A status object is constructed and pushed to the status queue.
        //          It would be dequeued after a specified interval and updated in the status bar.
        this.error = function (errorMessage, statusShowingTime, statusInterval) {
            var statusObject = {};
            statusObject.statusMessage = errorMessage;
            statusObject.statusType = statusInformation.statusConstants.ERROR;
            statusObject.borderStyle = statusInformation.statusConstants.ERROR.BORDER;
            statusObject.statusIcon = statusInformation.statusConstants.ERROR.ICON;
            statusObject.statusInterval = statusInterval || statusInformation.statusConstants.errorInterval;
            statusObject.statusShowingTime = statusShowingTime;
            enqueueStatus(statusObject);
        };
        
        this.warning = function (warningMessage, statusShowingTime) {
            var statusObject = {};
            statusObject.statusMessage = warningMessage;
            statusObject.statusType = statusInformation.statusConstants.WARNING;
            statusObject.borderStyle = statusInformation.statusConstants.WARNING.BORDER;
            statusObject.statusIcon = statusInformation.statusConstants.WARNING.ICON;
            statusObject.statusInterval = statusInformation.statusConstants.warningInterval;
            statusObject.statusShowingTime = statusShowingTime;
            enqueueStatus(statusObject);
        };
        
        this.information = function (informationMessage, statusShowingTime) {
            var statusObject = {};
            statusObject.statusMessage = informationMessage;
            statusObject.statusType = statusInformation.statusConstants.INFORMATION;
            statusObject.borderStyle = statusInformation.statusConstants.INFORMATION.BORDER;
            statusObject.statusIcon = statusInformation.statusConstants.INFORMATION.ICON;
            statusObject.statusInterval = statusInformation.statusConstants.informationInterval;
            statusObject.statusShowingTime = statusShowingTime;
            enqueueStatus(statusObject);
        };
        
        this.success = function (successMessage, statusShowingTime) {
            var statusObject = {};
            statusObject.statusMessage = successMessage;
            statusObject.statusType = statusInformation.statusConstants.SUCCESS;
            statusObject.borderStyle = statusInformation.statusConstants.SUCCESS.BORDER;
            statusObject.statusIcon = statusInformation.statusConstants.SUCCESS.ICON;
            statusObject.statusInterval = statusInformation.statusConstants.successInterval;
            statusObject.statusShowingTime = statusShowingTime;
            enqueueStatus(statusObject);
        };
        
        // function to enqueue the status object to the queue.
        // If no status is currently displayed it would call the statusUpdate function.
        // Otherwise the object is just enqueued to the status queue
        var enqueueStatus = function enqueueStatus(statusObject) {
            statusInformation.statusQueue.push(statusObject);
            if (!statusInformation.statusUpdate) {
                statusUpdate();
            }
        };
        
        // function to dequeue the status queue. The splice method returns an array from which the first element is indexed
        var dequeueStatus = function dequeueStatus() {
            return statusInformation.statusQueue.splice(0, 1)[0];
        };
        
        // function to display the status object in the UI
        var displayStatus = function displayStatus(statusObject) {
            $rootScope.appGlobals.statusInformation = statusObject;
        };
        
        // function to check if status queue contains elements to be displayed and displays the object
        // the function contains a $timeout function which would hold the current status for the specified period before dequeuing again
        // When all the status information is completed, the status object in the UI is made empty
        var statusUpdate = function statusUpdate() {
            if(deferredTimer) {
                $timeout.cancel(deferredTimer);
            }
            statusInformation.statusUpdate = true;
            var statusObject = dequeueStatus();        
    
            if( typeof statusObject != 'undefined') {
                $rootScope.appGlobals.animateStatus = true;
                $timeout(function() {
                    displayStatus(statusObject);
                    showTime = statusObject.statusShowingTime;
                    statusUpdate();
                }, statusObject.statusInterval);
            } else {
                statusObject = {};
                statusInformation.statusUpdate = false;            
                deferredTimer = $timeout(function() {
                    showTime = undefined;
                    displayStatus(statusObject);                
                    $rootScope.appGlobals.animateStatus = false;
                }, showTime || 6000);
            }
        };
    //	    statusUpdate(0);
    }]);