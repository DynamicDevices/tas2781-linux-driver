'use strict';
/*global CRC32*/

var CRC32 = require("../js/CRC32");

function Binary(binConfig) {
    this.configurationList = []
    this.binConfig = binConfig;
    this.platformType = '';
    this.devicesCount = '';
    this.amplifierType = [];
    this.deviceType = '';
}
Binary.prototype.addConfiguration = function() {
    var configName = "Configuration " + (this.configurationList.length + 1);
    var config = new Configuration(configName, this.binConfig);
    this.configurationList.push(config);
    
}

Binary.prototype.copyConfiguration = function(config) {
    var configName = config.configName + " copy";
    var copyConfig = new Configuration(configName, this.binConfig);
    config.blocksList.forEach(function(currentBlock) {
        copyConfig.blocksList.push(copyBlocksAndCommands(currentBlock));
    });
    this.configurationList.push(copyConfig);
}

Binary.prototype.loadData = function(data){
    var self = this;
    this.clearConfigData();
    data.configurationList.forEach(function(config, index){
        var configObj = new Configuration(config.configName, self.binConfig); 
        configObj.loadData(config);
        self.updateConfiguration(configObj,index);
    });
    this.platformType = data.platformType;
    this.devicesCount = data.devicesCount;
    this.amplifierType = data.amplifierType;
    if(!data.deviceType) {
        this.deviceType = "Non Integrated";
    } else {
        this.deviceType = data.deviceType;
    }
}
Binary.prototype.updateConfiguration = function(config, indx) {
    this.configurationList[indx] = config;
}
Binary.prototype.deleteConfiguration = function(index) {
    this.configurationList.splice(index, 1); // remove 1 element in specified index
}
Binary.prototype.clearConfigData = function() {
    this.configurationList = [];
}
Binary.prototype.swapConfiguration = function(from, to) {
    var list = this.configurationList;
    var fromObj = list[from];
    var toObj = list[to];
    this.configurationList[to] = fromObj;
    this.configurationList[from] = toObj;
}
Binary.prototype.clearHWSetupSettings = function(){
    this.platformType = '';
    this.devicesCount = '';
    this.amplifierType = [];
    this.deviceType = '';
};
Binary.prototype.toBinary = function(){
    var binary = [], configBinary = [], sizeOfConfigs = [], newConfigBinary;
    var binarySize, checksum = 0, binaryVersion , driverVersion, deviceTypes = [];

    var binConfig = this.binConfig;

    var getAmpTypeValue = function(type){
        var ampTypes = binConfig.types.amplifierType.values;
        return parseInt(ampTypes[type],16);
    };

    var getPlatformValue = function(type){
        var platforms = binConfig.types.platformType.values;
        return parseInt(platforms[type],16);
    };

    var getDeviceCountValue = function(count){
        var deviceCounts = binConfig.types.deviceCount.values;
        return parseInt(deviceCounts[count],16);
    };

    for (var k=0;k<this.binConfig.maxConfigs;k++ ){
        sizeOfConfigs.push(toBytesInt32(0));
    }
    for(var i=0; i<this.configurationList.length;i++){
        var configNameBuf = new Buffer(getConfigName(this.configurationList[i].configName, binConfig.configNameLength));
        newConfigBinary = Array.prototype.slice.call(configNameBuf).concat(this.configurationList[i].toBinary());
        sizeOfConfigs[i] = toBytesInt32(newConfigBinary.length);
        configBinary = configBinary.concat(newConfigBinary);
    }
    binarySize = this.binConfig.headerSize + configBinary.length;
    binaryVersion = this.binConfig.binaryVersion;
    driverVersion = this.binConfig.driverVersion;
    for(var j=0;j<this.binConfig.maxDevice;j++){
        deviceTypes[j] = 0;
        if(this.amplifierType[j]){
            deviceTypes[j] = getAmpTypeValue(this.amplifierType[j]);
        }
    }
    var sizeOfConfigsBinary = [];
    for(k=0;k<this.binConfig.maxConfigs;k++){
        sizeOfConfigsBinary = sizeOfConfigsBinary.concat(sizeOfConfigs[k]);
    }
    var time = Math.round((new Date().getTime())/1000);
    binary= binary
        .concat(toBytesInt32(binarySize))
        .concat(toBytesInt32(checksum))
        .concat(binaryVersion)
        .concat(driverVersion)
        .concat(toBytesInt32(time))
        .concat(getPlatformValue(this.platformType))
        .concat(0) // DeviceFamily
        .concat(0) // Reserved byte
        .concat(getDeviceCountValue( this.devicesCount))
        .concat(deviceTypes)
        .concat(toBytesInt32(this.configurationList.length))
        .concat(sizeOfConfigsBinary)
        .concat(configBinary);
    var tempBuf = new Buffer(binary);
    var crcVal = CRC32.buf(tempBuf);
    crcVal = fitCrcToFourBytes(crcVal);
    Array.prototype.splice.apply(binary, [4, crcVal.length].concat(crcVal));
    return new Buffer(binary);
};

function getConfigName(str, maxLen) {
    str = str.slice(0, maxLen);
    while(str.length < maxLen) {
        str += '\0';
    }
    return str;
}

Binary.prototype.isValid = function() {
    if(this.configurationList.length === 0){
        return {isValid: false, error:'Configurations are empty'}
    } else {
        for(var i=0; i<this.configurationList.length; i++) {
            var config = this.configurationList[i]
            var result = config.isValid();
            if(!result.isValid){
                return {isValid: false, error: config.configName + '-> ' +result.error, configIndx: i, blockIndx: result.blockIndx, commandIndx: result.commandIndx}
            }
        }
        return {isValid: true, error: ''};
    }
}

function Configuration(configName, binConfig) {
    this.blocksList = [];
    this.configName = configName || '';
    this.blockTypeValues = {};
    this.subBlockTypeValues = {};
    this.blockTypeValues = binConfig.types.blockType.values;
    this.subBlockTypeValues = binConfig.types.subBlockType.values;
}
Configuration.prototype.addBlock = function() {
    var blockName = "Block " + (this.blocksList.length + 1);
    var block = new Block(blockName, this);
    this.blocksList.push(block);
}
Configuration.prototype.copyBlock = function(blockIndex) {
    var currentBlock = this.blocksList[blockIndex];
    this.blocksList.push(copyBlocksAndCommands(currentBlock));
}
function copyBlocksAndCommands(currentBlock) {
    var block = new Block(currentBlock.blockName, currentBlock);
    block.blockType = currentBlock.blockType;
    block.deviceName = currentBlock.deviceName;
    block.deviceValue = currentBlock.deviceValue;
    block.deviceShortName = currentBlock.deviceShortName;
    currentBlock.commands.forEach( function (cmd){
        var command = new Command();
        command.book = cmd.book;
        command.page = cmd.page;
        command.register = cmd.register;
        command.mask = cmd.mask;
        command.data = cmd.data;
        command.delay = cmd.delay;
        command.comments = cmd.comments;
        block.commands.push(command);
    });
    return block;
}
Configuration.prototype.deleteBlock = function(index) {
    this.blocksList.splice(index, 1); // remove 1 element in specified index
};
Configuration.prototype.clearBlocks = function(){
    this.blocksList = [];
};
Configuration.prototype.loadData = function(data){
    var self = this;
    this.clearBlocks();
    data.blocksList.forEach(function(block, index){
        var blockObj = new Block(block.blockName, self); 
        blockObj.loadData(block);
        self.blocksList.push(blockObj);
    });
};
Configuration.prototype.toBinary = function(){
    var binary = [], blockBinary = [];
    for(var i=0; i<this.blocksList.length;i++){
        blockBinary = blockBinary.concat(this.blocksList[i].toBinary());
    }
    binary= binary
        .concat(toBytesInt32(this.blocksList.length))
        .concat(blockBinary);
    return binary;
};

Configuration.prototype.isValid = function() {
    if(this.blocksList.length === 0){
        return {isValid: false, error:'Blocks are not created'}
    } else {
        for(var i=0; i<this.blocksList.length; i++) {
            var block = this.blocksList[i];
            var result = block.isValid();
            if(!result.isValid){
                return {isValid: false, error: block.blockName + '-> ' +result.error, blockIndx: i, commandIndx: result.commandIndx}
            }
        }
        return {isValid: true, error: ''};
    }
}

function Block(blockName, config) {
    this.blockType = '';
    this.blockName = blockName || '';
    this.deviceName = '';
    this.commands = [];
    this.deviceValue = null;
    this.deviceShortName = '';
    this.blockTypeValues = {};
    this.subBlockTypeValues = {};
    this.blockTypeValues = config.blockTypeValues;
    this.subBlockTypeValues = config.subBlockTypeValues;
}

Block.prototype.addCommand = function(indx) {       
    var cmd = new Command();
    this.commands.splice(indx, 0, cmd); // adding at a particular index
}
Block.prototype.deleteCommand = function(index) {
    this.commands.splice(index, 1); // remove 1 element in specified index
}
Block.prototype.clearCommands = function(){
    this.commands = [];
};
Block.prototype.loadData = function(data){
    var self = this;
    this.clearCommands();
    data.commands.forEach(function(command, index){
        var commandObj = new Command(); 
        commandObj.loadData(command);
        self.commands.push(commandObj);
    });
    this.blockType = data.blockType;
    this.deviceName = data.deviceName;
    this.deviceValue = data.deviceValue;
    this.deviceShortName = data.deviceShortName;
};
Block.prototype.toJSON = function(){
    var blockObj = {};
    blockObj.blockName = this.blockName;
    blockObj.commands = this.commands ;
    blockObj.blockType = this.blockType;
    blockObj.deviceName = this.deviceName;
    blockObj.deviceValue = this.deviceValue;
    blockObj.deviceShortName = this.deviceShortName;
    return blockObj;
};
Block.prototype.toBinary = function(){
    var binary = [], subBlockBinary = [];
    var blockTypeValues = this.blockTypeValues;

    var getBlockTypeValue = function(type){        
        return parseInt(blockTypeValues[type],16);
    };

    var getRegWrites = function(subBlocks){
        var regWrites = [];
        for(var i=0; i<subBlocks.length;i++){
            regWrites = regWrites.concat(subBlocks[i].getRegWrites());
        }
        return regWrites;
    };

    this.subBlocks = commandsToSubBlocks(this.commands, this.subBlockTypeValues);
    for(var i=0; i<this.subBlocks.length;i++){
        subBlockBinary = subBlockBinary.concat(this.subBlocks[i].toBinary());
    }
    var values = getRegWrites(this.subBlocks);
    var checksum = calculateChecksum(values);
    var blockSize = subBlockBinary.length;
    var blockTypeValue = getBlockTypeValue(this.blockType);
    binary= binary.concat(parseInt(this.deviceValue,16))
        .concat(blockTypeValue)
        .concat([1,checksum])
        .concat(toBytesInt32(blockSize))
        .concat(toBytesInt32(this.subBlocks.length))
        .concat(subBlockBinary);
    return binary;
};

Block.prototype.isValid = function() {
    if(this.commands.length === 0){
        return {isValid: false, error:'Commands are not created'}
    } else if(this.blockType == '') {
        return {isValid: false, error:'Block type not selected'}
    } else if(this.deviceName == '' || this.deviceValue === null) {
        return {isValid: false, error:'Device not selected'}
    }
     else {
        for(var i=0; i<this.commands.length; i++) {
            var command = this.commands[i];
            var result = command.isValid();
            if(!result.isValid){
                return {isValid: false, error: 'Command ' + (i+1) + '-> ' +result.error, commandIndx: i}
            }
        }
        return {isValid: true, error: ''};
    }
}

function commandsToSubBlocks (commands, subBlockTypes){
    var subBlocks = [], singleWriteSubBlock = [], newSubBlock = {};
    var currentCmd;
    var checkAndPushSingleWrites = function(){
        if(singleWriteSubBlock.length){
            newSubBlock.type = 'SINGLE_BYTE_WRITES';
            newSubBlock.data = singleWriteSubBlock;
            subBlocks.push(newSubBlock);
            newSubBlock = new subBlock();
            newSubBlock.subBlockTypeValues = subBlockTypes;
            singleWriteSubBlock = [];
        }
    };
    var isBurstData = function(data){
        var values = data.split(' ');
        return values.length>1;
    };

    for(var i=0;i<commands.length;i++){
        currentCmd = commands[i];
        currentCmd.mask = currentCmd.mask == '' ? 'ff' : currentCmd.mask;
        newSubBlock = new subBlock();        
        newSubBlock.subBlockTypeValues = subBlockTypes;
        if(!currentCmd.data){
            checkAndPushSingleWrites();
            newSubBlock.type = 'DELAY';
            newSubBlock.delay = parseInt(currentCmd.delay);
            subBlocks.push(newSubBlock);
        } else if(isBurstData(currentCmd.data)){
            checkAndPushSingleWrites();
            newSubBlock.type = 'BURST_WRITES';
            newSubBlock.book = parseInt(currentCmd.book,16);
            newSubBlock.page = parseInt(currentCmd.page,16);
            newSubBlock.offset = parseInt(currentCmd.register,16);
            var values = toValues(currentCmd.data);
            if(values.length%4){
                var actualLength = parseInt(values.length/4)*4;
                var singleWrites = values.splice(parseInt(values.length/4)*4);
                for(var j=0;j<singleWrites.length;j++){
                    var newSubBlock2 = new subBlock();
                    newSubBlock2.subBlockTypeValues = subBlockTypes;
                    newSubBlock2.book = parseInt(currentCmd.book,16);
                    newSubBlock2.page = parseInt(currentCmd.page,16);
                    newSubBlock2.offset = parseInt(currentCmd.register,16)+actualLength+j;
                    newSubBlock2.values = singleWrites[j];
                    singleWriteSubBlock.push(newSubBlock2);
                }
            }
            newSubBlock.values = values;
            if(values){
                subBlocks.push(newSubBlock);
            }

        } else if(parseInt(currentCmd.mask,16) != 0xFF){
            checkAndPushSingleWrites();
            newSubBlock.type = 'FIELD_WRITES';
            newSubBlock.book = parseInt(currentCmd.book,16);
            newSubBlock.page = parseInt(currentCmd.page,16);
            newSubBlock.offset = parseInt(currentCmd.register,16);
            newSubBlock.mask = parseInt(currentCmd.mask,16);
            newSubBlock.values = toValues(currentCmd.data);
            subBlocks.push(newSubBlock);
        } else {
            newSubBlock.book = parseInt(currentCmd.book,16);
            newSubBlock.page = parseInt(currentCmd.page,16);
            newSubBlock.offset = parseInt(currentCmd.register,16);
            newSubBlock.values = toValues(currentCmd.data);
            singleWriteSubBlock.push(newSubBlock);
        }
    }
    checkAndPushSingleWrites();
    return subBlocks;
}

function Command() {
    this.book = '0';
    this.page = '0';
    this.register = '0';
    this.mask = 'ff';
    this.data = '';
    this.delay = '';
    this.comments = '';
}
Command.prototype.loadData = function(data){
    this.book = data.book;
    this.page = data.page;
    this.register = data.register;
    this.mask = data.mask;
    this.data = data.data;
    this.delay = data.delay;
    this.comments = data.comments;
};
Command.prototype.isValid = function() {
    if(this.delay == '' || this.delay == null || this.delay == undefined) {
        if(this.book == '' || this.book == null || this.book == undefined) {
            return {isValid: false, error: 'Value of Book is invalid'}
        }
        if(this.page == '' || this.page == null || this.page == undefined) {
            return {isValid: false, error: 'Value of Page is invalid'}
        }
        if(this.register == '' || this.register == null || this.register == undefined) {
            return {isValid: false, error: 'Value of Register is invalid'}
        }
        if(this.data == '' || this.data == null || this.data == undefined) {
            return {isValid: false, error: 'Value of Data is invalid'}
        }
        return {isValid: true, error: ''};
    }
    return {isValid: true, error: ''};
}

function subBlock(id){
    this.id = id || '';
    this.subBlockTypeValues = {};
}

subBlock.prototype.getRegWrites = function(){
    var values = [];
    switch (this.type) {
        case 'BURST_WRITES':
            values= values.concat(this.values);
            break;
        case 'SINGLE_BYTE_WRITES':
            for(var i=0;i<this.data.length;i++){
                values= values.concat(this.data[i].values);
            }
            break;
        case 'FIELD_WRITES':
            values= values.concat(this.values[0] && this.mask);
            break;
        default:
            break;
    }
    return values;
};

subBlock.prototype.toBinary = function(){
    var binary = [];
    var subBlockTypes = this.subBlockTypeValues;

    function toBytesInt16(num) {
        return [
             (num & 0xff00) >> 8,
             (num & 0xff),
        ];
    }

    var getSubBlockTypeValue = function(type){        
        return parseInt(subBlockTypes[type],16);
    }

    //Add subBlock Type data
    binary= binary.concat(0);
    binary= binary.concat(getSubBlockTypeValue(this.type));
    //Add subblock specific binary data
    switch (this.type) {
        case 'DELAY':
            
            binary= binary.concat(toBytesInt16(this.delay));
            break;
        case 'BURST_WRITES':
            binary= binary.concat(toBytesInt16(this.values.length));
            binary= binary.concat([this.book, this.page, this.offset, 0]);
            binary= binary.concat(this.values);
            break;
        case 'FIELD_WRITES':
            binary= binary.concat([0, this.mask]);
            binary= binary.concat([this.book, this.page, this.offset, this.values[0]]);
            break;
        case 'SINGLE_BYTE_WRITES':
            binary= binary.concat(toBytesInt16(this.data.length));
            for(var j=0;j<this.data.length;j++){
                var newWrite = this.data[j];
                binary= binary.concat([newWrite.book, newWrite.page, newWrite.offset, newWrite.values[0]]);
            }
            break;
    }
    return binary;
};


/*Utility Functions*/

var toValues = function(data){
    var values = data.split(' ');
    values.forEach(function(value, i){
        value = parseInt(value, 16);
        if(value>255){
            value = 255;
        }
        values[i]= value;
    });
    return values;
};

function toBytesInt32(num) {
    if(!num){
        num = 0;
    }
    var str = num.toString(16);
    var concatStr = "00000000"+str;
    var finalStr = concatStr.slice(-8);
    return [
         parseInt(finalStr.slice(0,2),16),
         parseInt(finalStr.slice(2,4),16),
         parseInt(finalStr.slice(4,6),16),
         parseInt(finalStr.slice(6,8),16)
    ];
}

function increaseByteSizeUptoFour(bytesTo, hexValStr) {
    //make sure hexValStr is proper - do not remove this
    hexValStr = toHexString(parseInt(hexValStr, 16));
    //increase the size
    var concatenatedStr = "00000000" + hexValStr;
    var finalStr = concatenatedStr.slice(-2*bytesTo);
    return finalStr;
}

function fitCrcToFourBytes(num) {
    var arr = new ArrayBuffer(4);
    var view = new DataView(arr);
    view.setInt32(0, num, false);
    var newCrcBinStr = '', eightBitStr;
    var i = 0;
    while (i < 4) {
        eightBitStr = ("00000000"+view.getUint8(i).toString(2)).slice(-8);
        newCrcBinStr += eightBitStr;
        ++i;
    }
    var decVal = parseInt(newCrcBinStr, 2);
    return  toBytesInt32(decVal);
}

function calculateChecksum(values, seed) {
    var checksum = seed || 0;

    for (var i=0; i<values.length; i++) {
        checksum = getChecksum([checksum, values[i]]);
    }

    return checksum;
}

function getChecksum(registerArray){
    var size_input,
        initial_state = [], cipher_temp = [],
        checksum_int =[];

    // Function to convert int array to byte array
    var intToByte = function(n){
        if (n < 0 || n > 255 || n % 1 !== 0) {
            throw new Error(n + " does not fit in a byte");
        }
        var bytearrayString=("000000000" + n.toString(2)).substr(-8)
        return (bytearrayString.split('').map(Number));
    }

    for (var cnt= 0; cnt < registerArray.length; cnt ++){
        cipher_temp.push(intToByte(registerArray[cnt]));
    }

    // Implement the Checksum Function
    size_input = cipher_temp.length;

    for(var i = 0; i<16 ; i ++){
        initial_state[i]=0;
    }

    for (var loop_index = 0; loop_index < size_input; loop_index++){
        for (var cnt =0; cnt< 8; cnt ++){
            initial_state[cnt]= cipher_temp[loop_index][cnt];
        }

        for (var i =0; i < 8; i++){
            if(initial_state[i]==1){
                initial_state[i]= +!(initial_state[i]);
                initial_state[i+6]= +!(initial_state[i+6]);
                initial_state[i+7]= +!(initial_state[i+7]);
                initial_state[i+8]= +!(initial_state[i+8]);
            }
        }

       checksum_int.push(initial_state.slice(8,16));

    }

    if (checksum_int.length > 0) {
        return parseInt(checksum_int[size_input-1].reduce(function(preVal, val){
            return preVal+val.toString();
        }, ""), 2);
    } else {
        return 0;
    }

}